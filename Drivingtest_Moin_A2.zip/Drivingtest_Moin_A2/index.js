//Packages
const express = require('express')
const path = require('path')
const ejs = require('ejs')
const mongoose = require('mongoose')
const DriveTest = require('./models/DriveTest')

//Initializing Express App
const app = new express()

//View Templating engine
app.set('view engine', 'ejs')

//Setting folder for Static files
app.use(express.static('public'))

//Middlewares
app.use(express.json())
app.use(express.urlencoded())

//Connection string to connect with MongoDB Atlas
mongoose.connect('mongodb+srv://admin:admin@tigerdata1.ddmfj.mongodb.net/DriverTest_DB?retryWrites=true&w=majority&appName=Tigerdata1')

//Request Handlers (get,post,put)
app.get('/', (req,res)=>{
    res.render('index', {pageHeading: 'Dashboard'}) //index.ejs
})

app.get('/g2test', (req,res)=>{
    res.render('g2test', {pageHeading: 'G2'}) //about.ejs
})


app.get('/g_test', (req, res) => {
    res.render('gtest', { userF: null, user: null, pageHeading: 'G' });
});

app.get('/login', (req,res)=>{
    res.render('login', {pageHeading: 'Login'}) //post.ejs
})

app.post('/person/fetch', async (req, res) => {
    try {
        const { licenseNumber } = req.body;

        const userF = await DriveTest.findOne({ licenceNumber: licenseNumber });

        if (userF) {
            res.render('gtest', {
                userF: true,
                user: userF, 
            });
        } else {
            res.render('gtest', {
                userF: false,  
            });
        }
    } catch (error) {
        console.error(error);
    }
});

app.post('/person/update', async (req, res) => {
    try {
        const { licenceNumber, make, model, year, plateNumber } = req.body;

        const updatedUser = await DriveTest.findOneAndUpdate(
            { licenceNumber },  
            {
                $set: {
                    'carDetails.make': make,  
                    'carDetails.model': model,
                    'carDetails.year': year,
                    'carDetails.plateNumber': plateNumber,
                },
            },
            { new: true } 
        );

        if (updatedUser) {
            res.render('gtest', {
                userF: true,
                user: updatedUser,
            });
        } else {
            console.log('User not found');
        }
    } catch (error) {
        res.status(500).send("An error occurred while updating the user.");
    }
});


app.post("/users/store", async (req, res) => {
    try {
        const { firstName, lastName, licenceNumber, age, carDetails: {make, model, year, plateNumber} } = req.body;
        console.log(make);
        await DriveTest.create({
            firstName,
            lastName,
            licenceNumber,
            age,
            carDetails: {
                make,
                model,
                year,
                plateNumber,
            },
        });
        res.redirect("/");
    } catch (error) {
        console.error(error);
    }
})

//Port number
app.listen(4000, ()=>{
    console.log('App is running at 4000 port')
})