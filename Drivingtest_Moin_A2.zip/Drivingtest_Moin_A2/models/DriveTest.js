const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DriveTestSchema = new Schema({
    firstName: String,
    lastName: String,
    licenceNumber: String,
    age: Number,
    carDetails: {
        make: String,
        model: String,
        year: Number,
        plateNumber: String
    }
});

const DriveTest = mongoose.model('User', DriveTestSchema);

module.exports = DriveTest;