const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DriveTestSchema = new Schema({
    firstName: String,
    lastName: String,
    licenceNumber: String,
    age: Number,
    carDetails: {
        make: String,
        model: String,
        year: Number,
        plateNumber: String
    }
});

// const DriveTest = mongoose.model('User', DriveTestSchema);

// module.exports = DriveTest;


// const mongoose = require("mongoose");
// const bcrypt = require("bcrypt");

// const Schema = mongoose.Schema;

// const DriveTestSchema = new Schema({
//     firstName: { type: String, default: "default" },
//     lastName: { type: String, default: "default" },
//     licenceNumber: { type: String, default: "default" }, // You can encrypt this if needed
//     age: { type: Number, default: 0 },
//     username: { type: String, required: true, unique: true },
//     password: { type: String, required: true },
//     userType: { type: String, enum: ["Driver", "Examiner", "Admin"], default: "Driver" },
//     carDetails: {
//         make: { type: String, default: "default" },
//         model: { type: String, default: "default" },
//         year: { type: Number, default: 0 },
//         plateNumber: { type: String, default: "default" }
//     }
// });

// // Hash password before saving the user
// DriveTestSchema.pre("save", async function (next) {
//     if (!this.isModified("password")) return next();

//     try {
//         const salt = await bcrypt.genSalt(10);
//         this.password = await bcrypt.hash(this.password, salt);
//         next();
//     } catch (err) {
//         next(err);
//     }
// });

// // Compare entered password with hashed password
// DriveTestSchema.methods.comparePassword = async function (enteredPassword) {
//     return await bcrypt.compare(enteredPassword, this.password);
// };

// // Create and export DriveTest Model
// const DriveTest = mongoose.model("DriveTest", DriveTestSchema);

// module.exports = DriveTest;
